package exercicios;

public class Somatoria {
public static void main(String[] args) {
	int n1=1,i=1,nf=1;
	while (i<=100) {
		System.out.println(nf);
		n1=n1+1;
		nf=nf+n1;
		i=i+1;
	}
}
}
